<?php

$server = "localhost";
$user = "root";
$password = "";
$db = "course_discuss";

$connect = new mysqli($server, $user, $password, $db);
