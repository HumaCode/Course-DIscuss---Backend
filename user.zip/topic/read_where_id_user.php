<?php

include '../connection.php';

$id_user = $_POST['id_user'];

$sql  = "SELECT * FROM topic
        WHERE 
        id_user = '$id_user'";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    while ($get_row = $result->fetch_array()) {
        $data[] = $get_row;
    }

    echo json_encode(array(
        "success" => true,
        "data" => $data,
    ));
} else {
    echo json_encode(array(
        "success" => false,
        "data" => [],
    ));
}
